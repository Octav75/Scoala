package com.sda.spring.example.interfaces;

public interface BeanName {

    public String getName();
}
