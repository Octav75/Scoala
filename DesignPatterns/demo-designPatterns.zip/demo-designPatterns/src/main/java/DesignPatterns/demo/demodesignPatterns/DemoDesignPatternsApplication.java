package DesignPatterns.demo.demodesignPatterns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDesignPatternsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDesignPatternsApplication.class, args);
	}

}
