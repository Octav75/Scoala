package com.sda.school.emtity.classModel;

import com.sda.school.emtity.AbstractService;
import com.sda.school.exception.NullIdException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClassServiceImpl extends AbstractService<Long, ClassModel, ClassRepository> {

    private ClassRepository classRepository;

    @Autowired
    public ClassServiceImpl(ClassRepository classRepository) {
        super(classRepository);
    }

    @Override
    public ClassModel add(ClassModel classModel) {
        if(classModel.getName()==null) {
            classModel.setName("Anonim");
        }
        return super.add(classModel);
    }



}
