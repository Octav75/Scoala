package com.sda.school.emtity.student;

import com.sda.school.emtity.AbstractModel;
import com.sda.school.exception.NullIdException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
//rest = deoarece face un call care functioneaza pe baza de http
public class StudentController extends AbstractModel {

    private StudentServiceImpl studentService;

    @Autowired
    public StudentController (StudentServiceImpl studentService){

        this.studentService=studentService;
    }


    @PostMapping (consumes = "application/json", produces = "application/json",
            path = "/rest/class/{classId}/student")
    /*
    @RequestMapping(consumes = "application/json", produces = "application/json",
            method = RequestMethod.POST)
            - este o alta varianta de scriere
    */
    public ResponseEntity sdd(@PathVariable Long classId, @RequestBody StudentModel studentModel){
        try {
            StudentModel addedStudentModel = studentService.add(classId, studentModel);
            return ResponseEntity.ok(addedStudentModel);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }


    }

    //pentru getOne
    @GetMapping(produces = "application/json", path = "rest/student/{id}") //concateneaza inca un /id dupa rest/student
    public ResponseEntity<StudentModel> get(@PathVariable ("id") Long id){
        Optional<StudentModel> student = studentService.get(id);
        if(student.isPresent()){
            return ResponseEntity.ok(student.get());
        } else {
            return ResponseEntity.notFound().build(); //build este pt a construi un ResponseEntity
        }
    }

    @GetMapping(produces = "application/json", path = "/rest/student")
    public ResponseEntity<List<StudentModel>> get(){
        List<StudentModel> students = studentService.get();
        if(students.isEmpty()){
            return ResponseEntity.notFound().build();
        }else {
            return ResponseEntity.ok(students);
        }
    }

    @DeleteMapping(path = "/rest/student/{id}")
    public ResponseEntity delete(@PathVariable ("id") Long id) {
        try {
            studentService.delete(id);
        }catch (EmptyResultDataAccessException e){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().build();
    }

    @PutMapping(consumes = "application/json", path = "/rest/student")
    public ResponseEntity<StudentModel> update(@RequestBody StudentModel studentModel){
        try {
            Optional<StudentModel> updatedStudent = studentService.update(studentModel);
            if(updatedStudent.isPresent()) {
                return ResponseEntity.ok(updatedStudent.get());
            }else {
                return ResponseEntity.notFound().build();
            }
        }catch (NullIdException e) {
            return ResponseEntity.badRequest().build();
        }


    }

}
