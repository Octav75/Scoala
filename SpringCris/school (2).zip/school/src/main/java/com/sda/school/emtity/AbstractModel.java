package com.sda.school.emtity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Timestamp;

@MappedSuperclass
@Getter
@Setter
public class AbstractModel<ID_TYPE> {

    @Column(nullable = false, updatable = false, insertable = false,
            columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    @JsonIgnore
    protected Timestamp created;

//    @Column(nullable = false, updatable = false, insertable = false,
//            columnDefinition = "TIMESTAMP DEFAULT CURRENTtIMESTAMP")
//    protected Timestamp updated;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private ID_TYPE id;
}
