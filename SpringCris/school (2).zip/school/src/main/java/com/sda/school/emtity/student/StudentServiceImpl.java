package com.sda.school.emtity.student;

import com.sda.school.emtity.AbstractService;
import com.sda.school.emtity.classModel.ClassModel;
import com.sda.school.emtity.classModel.ClassRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentServiceImpl extends AbstractService<Long, StudentModel, StudentRepository> {


    private ClassRepository classRepository;

    @Autowired
    public StudentServiceImpl(StudentRepository studentRepository, ClassRepository classRepository){
        super(studentRepository);
        this.classRepository = classRepository;
    }

    public StudentModel add(Long classId, StudentModel studentModel) throws Exception{
        Optional<ClassModel> belongingClass = classRepository.findById(classId);

        if(belongingClass.isPresent()){
            if(studentModel.getName()==null){
                studentModel.setName("Anonim");
            }
            studentModel.setBelongingClass(belongingClass.get());
            return repository.saveAndFlush(studentModel);
        } else {
            throw new Exception("The requested class does not exist!");
        }
    }

}
