package com.sda.school.emtity.student;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sda.school.emtity.AbstractModel;
import com.sda.school.emtity.classModel.ClassModel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class StudentModel extends AbstractModel<Long> {

     private String name;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)// optional false pt ca nu putem avea un student fara clasa
    @JoinColumn(name = "class__id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private ClassModel belongingClass;

}
