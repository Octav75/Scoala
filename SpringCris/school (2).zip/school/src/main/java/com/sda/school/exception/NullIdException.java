package com.sda.school.exception;

public class NullIdException extends Exception {
    public NullIdException(String message) {
        super(message);
    }

}
