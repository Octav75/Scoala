package com.sda.school.emtity.classModel;

import com.sda.school.emtity.AbstractModel;
import com.sda.school.exception.NullIdException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rest/class")
public class ClassController extends AbstractModel {

    private ClassServiceImpl classService;

    @Autowired
    public ClassController(ClassServiceImpl classService) {
        this.classService=classService;
    }

    @PostMapping(consumes = "application/json", produces = "application/json")
    public ResponseEntity<ClassModel> add(@RequestBody ClassModel classModel){
        ClassModel addedClassModel1 = classService.add(classModel);
        return ResponseEntity.ok(addedClassModel1);
    }

    @RequestMapping(produces = "application/json", path = "/{id}")
    public ResponseEntity<ClassModel> get(@PathVariable ("id") Long id){
        Optional<ClassModel> classModel = classService.get(id);
        if(classModel.isPresent()) {
            return ResponseEntity.ok(classModel.get());
        }
        return ResponseEntity.notFound().build();
    }

    @RequestMapping(produces = "application/json")
    public ResponseEntity<List<ClassModel>> get() {
        List<ClassModel> classes = classService.get();
        if(classes.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(classes);
        }

    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity delete(@PathVariable Long id) {
        try {
            classService.delete(id);
        } catch (EmptyResultDataAccessException e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().build();
    }

    @PutMapping(consumes = "application/json")
    public ResponseEntity update(@RequestBody ClassModel classModel ) {
        try {
            Optional<ClassModel> updatedClassModel = classService.update(classModel);
            if(updatedClassModel.isPresent()){
                return ResponseEntity.ok(updatedClassModel.get());
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (NullIdException e) {
                return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
